package com.minnwest.testcases;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.SkipException;
import org.testng.annotations.Test;

import com.minnwest.pages.LoginPage;
import com.minnwest.utilities.TestUtil;

public class Minnwest_Login extends LoginPage{

	
	@Test(dataProviderClass = TestUtil.class, dataProvider = "dp")
	public void minnwest_Login(Hashtable<String,String> data) throws InterruptedException, IOException {

		if(!(TestUtil.isTestRunnable("Minnwest_Login", excel))){
			
			throw new SkipException("Skipping the test "+"Minnwest_Login".toUpperCase()+ "as the Run mode is NO");
		}
		Thread.sleep(5000);
		setusername("username_XPATH",data.get("username"));
		Thread.sleep(3000);
		setpassword("password_XPATH",data.get("password"));
		Thread.sleep(3000);
		clicklogin("login_button_XPATH");
		Thread.sleep(3000);
		
		


		Thread.sleep(5000);

//		List<WebElement> accountTotal = driver
//				.findElements(By.xpath("//label[@class=\"-kony-ca-middleleft sknLblSSPSB42424215Px\"]"));

		List<WebElement> accountNames = driver.findElements(By.xpath(
				"//label[@style=\"transform-origin: 50% 50%; opacity: 1; padding: 0% 1% 0% 0%; z-index: 1; white-space: nowrap; margin-left: 17px; top: calc(50% - 9px);\"]"));

		List<WebElement> checkingAccount = driver.findElements(By.xpath("//label[text()=\"Checking\"]"));
		
		List<WebElement> savingsAccount = driver.findElements(By.xpath("//label[text()=\"Savings\"]"));

		List<WebElement> depositeAccount = driver.findElements(By.xpath("//label[text()=\"Deposit\"]"));
		
		List<WebElement> loanAccount = driver.findElements(By.xpath("//label[text()=\"Loan\"]"));

		
		List<String> accountNamesList = new ArrayList<String>();
		for (WebElement accountNamess : accountNames) {

			accountNamesList.add(accountNamess.getText());
		}

		// Create a new Excel workbook and sheet
		Workbook workbook = new XSSFWorkbook();
		Sheet sheet = workbook.createSheet("ACCOUNTS_DATA");
		// Iterate over the gettext data and add it to the Excel sheet

//		Iteration for account names
		int rowNum = 0;

		Row excelRow = sheet.createRow(rowNum);
		int columnNum = 0;
		for (WebElement cell : accountNames) {
			Cell excelCell = excelRow.createCell(columnNum++);
			excelCell.setCellValue(cell.getText());
			System.out.println(cell);
		}

//		Account total lists		
//		List<String> accountTotalsList = new ArrayList<String>();
//		for (WebElement accountTotals : accountTotal) {
//			accountTotalsList.add(accountTotals.getText());
//
//		}

		
//		Iteration for checking accounts total list
		int checkingrowNumber = 1;

		Row excelRow1 = sheet.createRow(1);
		int checkingcolumnNumber = 0;
		for (WebElement cell : checkingAccount) {
			Cell excelCell = excelRow1.createCell(0);
				excelCell.setCellValue(checkingAccount.size());
			System.out.println(cell);

		}
		
//		Iteration for checking accounts total list
		int savingrowNumber = 1;

//		Row excelRow2 = sheet.createRow(1);
		int savingcolumnNumber = 1;
		for (WebElement cell : savingsAccount) {
			Cell excelCell = excelRow1.createCell(1);
				excelCell.setCellValue(savingsAccount.size());
			System.out.println(cell);
		}
		
//		Iteration for checking accounts total list
		int depositerowNumber = 1;

//		Row excelRow3 = sheet.createRow(1);
		int depositecolumnNumber = 2;
		for (WebElement cell : depositeAccount) {
			Cell excelCell = excelRow1.createCell(2);
				excelCell.setCellValue(depositeAccount.size());
			System.out.println(cell);
		}
		
//		Iteration for checking accounts total list

		int loanrowNumber = 1;

//		Row excelRow4 = sheet.createRow(1);
		int loancolumnNumber = 3;
		for (WebElement cell : loanAccount) {
			Cell excelCell = excelRow1.createCell(3);
				excelCell.setCellValue(loanAccount.size());
			System.out.println(cell);
		}
		
		// Save the workbook to a file
		FileOutputStream outputStream = new FileOutputStream(new File(
				"C:\\Users\\UshaAtteti-Kairos\\Downloads\\IntegrationMinWestRepo-test1 (2)\\IntegrationMinWestRepo-test1\\src\\test\\resources\\excel\\AccountDetails.xlsx"));
		workbook.write(outputStream);
		outputStream.close();

		System.out.println(checkingAccount.size());
		System.out.println(savingsAccount.size());
		System.out.println(depositeAccount.size());
		System.out.println(loanAccount.size());
		
//		System.out.println(accountNamesList.get(0) + ":" + accountTotalsList.get(0));
//		System.out.println(accountNamesList.get(1) + ":" + accountTotalsList.get(1));
//		System.out.println(accountNamesList.get(2) + ":" + accountTotalsList.get(2));
//		System.out.println(accountNamesList.get(3) + ":" + "1");
		
		
		
		Thread.sleep(5000);
		click("sinout_CLASS_XPATH");
		Thread.sleep(6000);
		click("YES_XPATH");
		Thread.sleep(3000);
		click("tackservey_XPATH");
		Thread.sleep(3000);
		click("rate_XPATH");
		Thread.sleep(3000);
		click("submit_XPATH");
		Thread.sleep(3000);
		click("servey_XPATH");
		Thread.sleep(3000);
		click("Yes_XPATH");
		Thread.sleep(3000);
		click("TRANSFER_XPATH");
		Thread.sleep(3000);
		click("SUBMIT_XPATH");
		Thread.sleep(3000);
		click("DONE_XPATH");
		Thread.sleep(3000);
		

//		click("checkingAccounts2_XPATH");
//		Thread.sleep(5000);
//		click("transfer_XPATH");
//		Thread.sleep(5000);
//		click("search_XPATH");
//		Thread.sleep(5000);
//		click("transferAccount_XPATH");
//		Thread.sleep(5000);
//		click("amount_XPATH");
//		Thread.sleep(5000);
//		type("amount_XPATH","2.00");
//		Thread.sleep(5000);
//		click("selectBox_XPATH");
//		Thread.sleep(5000);
//		select("selectBox_XPATH","Once");
//		Thread.sleep(5000);
//		click("calender_XPATH");
//		Thread.sleep(5000);
//		click("optional_XPATH");
//		Thread.sleep(5000);
//		type("optional_XPATH","Kairos");
//		Thread.sleep(5000);
//		click("continue_XPATH");
//		Thread.sleep(5000);
//		click("confirm_XPATH");
//		Thread.sleep(8000);
//		WebElement finalSnapShot = driver.findElement(By.xpath("//label[@aria-label=\"We successfully completed the transfer\"]"));
//		System.out.println(finalSnapShot);
//		Thread.sleep(6000);
//		TakeScreenshot(finalSnapShot);
//		Thread.sleep(6000);
//		click("signout_XPATH");
//		Thread.sleep(6000);
//		click("yes_XPATH");
//		Thread.sleep(6000);
//		click("survey_XPATH");
//		Thread.sleep(6000);
//		click("star_XPATH");
//		Thread.sleep(6000);
//		click("submit_XPATH");
//		Thread.sleep(6000);
//		click("done_XPATH");
//		Thread.sleep(6000);
	
//		clicksinout("sinout_CLASS_XPATH");
//		Thread.sleep(6000);
//		clickYES("YES_XPATH");
//		Thread.sleep(3000);
//		clicktackservey("tackservey_XPATH");
//		Thread.sleep(3000);
//		clickrate("rate_XPATH");
//		Thread.sleep(3000);
//		clicksubmit("submit_XPATH");
//		Thread.sleep(3000);
//		clickservey("servey_XPATH");
//		Thread.sleep(3000);
//		clickYes("Yes_XPATH");
//		Thread.sleep(3000);
//		clickTRANSFER("TRANSFER_XPATH");
//		Thread.sleep(3000);
//		clickSUBMIT("SUBMIT_XPATH");
//		Thread.sleep(3000);
//		clickDONE("DONE_XPATH");
//		Thread.sleep(3000);
//		
		
		
		
//		clicklogin("signOut_XPATH");
//		Thread.sleep(3000);
//		clicklogin("approve_XPATH");
//		Thread.sleep(3000);
//		clicktake("take-XPATH");
//		Thread.sleep(4000);
		

	}
	
}
