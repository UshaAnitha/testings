package com.minnwest.pages;

import com.minnwest.base.TestBase;


public class LoginPage extends TestBase{
	
	
	public  void setusername(String loc,String uname) {
		
		type(loc,uname);

	}
	
public  void setpassword(String loc,String pwd) {
		
	type(loc,pwd);

	}
public void clicklogin(String loc) {
	
	click(loc);

}
public void clicktake(String loc) {
	click(loc);
	
}
public void clicksinout(String loc) {
	click(loc);
}
public void clickYES(String loc) {
	click(loc);
}
public void clicktackservey(String loc) {
	click(loc);
	
}
public void clickrate(String loc) {
	click(loc);
	
}
public void clicksubmit(String loc) {
	click(loc);
}
public void clickservey(String loc) {
	click(loc);
}
public void clickYes(String loc) {
	click(loc);
	
}
public void clickTRANSFER(String loc) {
	click(loc);
}
public void clickSUBMIT(String loc) {
	click(loc);
}
public void clickDONE(String loc) {
	click(loc);
}
}

	
	


