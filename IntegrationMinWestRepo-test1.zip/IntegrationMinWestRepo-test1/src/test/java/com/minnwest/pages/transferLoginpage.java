package com.minnwest.pages;

import com.minnwest.base.TestBase;


public class transferLoginpage extends TestBase {

	public void setusername(String loc, String uname) {

		type(loc, uname);

	}

	public void setpassword(String loc, String pwd) {

		type(loc, pwd);

	}

	public void clicklogin(String loc) {

		click(loc);

	}

	//public void clicktransfer(String loc) {
		//click(loc);
		
		
	//}
	//public void clicktransfers(String loc) {
		//click(loc);
	//}
	//public void clickTransferActivities(String loc, String value) {
		//select(loc, value);
	public void ClickCheckingAccounts(String loc) {
		
		click(loc);
	}
	public void ClickCheckingTransfer(String loc) {
		
		click(loc);
	}
	public void ClickTransferTo(String loc)
	{
		click(loc);
	}
	
	public void clickmysavingsaccount(String loc)
	{
		click(loc);
		

	
	}
	public void enterAmount(String loc, String value) {
		type(loc,value);
	}
	public void clickfrequency(String loc)
	{
		click(loc);
	}
	public void clicksendon(String loc)
	{
		click(loc);
	}
	public void clickcontinue(String loc)
	{
		click(loc);
	}
	public void clickconform(String loc)
	{
		click(loc);
	}
	public void clickReferencenumber(String loc)
	{
		click(loc);
	}
	//public void clicksinout(String loc)
	//{
		//click(loc);
	//}
	//public void clickyes(String loc)
	//{
		//click(loc);
	//}
	//public void clicktacksurvey(String loc)
	//{
		//click(loc);
	//}
	
	public void clicksinout(String loc) {
		click(loc);
	}
	public void clickYES(String loc) {
		click(loc);
	}
	public void clicktackservey(String loc) {
		click(loc);
		
	}
	public void clickrate(String loc) {
		click(loc);
		
	}
	public void clicksubmit(String loc) {
		click(loc);
	}
	public void clickservey(String loc) {
		click(loc);
	}
	public void clickYes(String loc) {
		click(loc);
		
	}
	public void clickTRANSFER(String loc) {
		click(loc);
	}
	public void clickSUBMIT(String loc) {
		click(loc);
	}
	public void clickDONE(String loc) {
		click(loc);
	}
	}
	
	
	

	
	
	
